var _table___graph_8c =
[
    [ "draw_table_graph", "_table___graph_8c.html#a3ba597fbaa34400c5ef93b1980aeb526", null ],
    [ "init_table_graph", "_table___graph_8c.html#a3256b9dedc7f0c5d1543984f6efe5fe3", null ],
    [ "sort_table_graph", "_table___graph_8c.html#a6c347bb6e116b9348ab32bc117d266d6", null ]
];