var searchData=
[
  ['function_5fdetails',['FUNCTION_DETAILS',['../struct_f_u_n_c_t_i_o_n___d_e_t_a_i_l_s.html',1,'']]]
];
