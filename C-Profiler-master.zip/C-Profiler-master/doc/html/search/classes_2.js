var searchData=
[
  ['node',['NODE',['../struct_n_o_d_e.html',1,'']]]
];
