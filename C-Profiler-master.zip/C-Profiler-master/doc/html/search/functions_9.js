var searchData=
[
  ['resize_5ftree_5fblock_5farray',['resize_tree_block_array',['../_tree___block_8h.html#afed1a1e97d855f096de0a929fa0b8816',1,'resize_tree_block_array(Tree_Block **t_blocks, size_t size, size_t *max):&#160;Tree_Block.c'],['../_tree___block_8c.html#afed1a1e97d855f096de0a929fa0b8816',1,'resize_tree_block_array(Tree_Block **t_blocks, size_t size, size_t *max):&#160;Tree_Block.c']]]
];
