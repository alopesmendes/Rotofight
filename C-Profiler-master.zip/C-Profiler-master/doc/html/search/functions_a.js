var searchData=
[
  ['sort_5ftable',['sort_table',['../_table_8h.html#a01617446a68569b63c1ab6b903d35319',1,'sort_table(Table *t, int(*sort_fct)(const void *, const void *)):&#160;Table.c'],['../_table_8c.html#a01617446a68569b63c1ab6b903d35319',1,'sort_table(Table *t, int(*sort_fct)(const void *, const void *)):&#160;Table.c']]],
  ['sort_5ftable_5fgraph',['sort_table_graph',['../_table___graph_8h.html#a6c347bb6e116b9348ab32bc117d266d6',1,'sort_table_graph(Table_Graph *table_graph, int sort_type):&#160;Table_Graph.c'],['../_table___graph_8c.html#a6c347bb6e116b9348ab32bc117d266d6',1,'sort_table_graph(Table_Graph *table_graph, int sort_type):&#160;Table_Graph.c']]]
];
