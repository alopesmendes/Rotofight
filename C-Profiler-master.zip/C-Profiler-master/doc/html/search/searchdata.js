var indexSectionsWithContent =
{
  0: "_abcdfghilmnprstwxy",
  1: "bfnt",
  2: "bcgmt",
  3: "abcdfgilprst",
  4: "abcfhimnrstwxy",
  5: "_mnprs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros"
};

