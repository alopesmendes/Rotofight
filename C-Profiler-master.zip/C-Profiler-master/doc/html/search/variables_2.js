var searchData=
[
  ['calls_5fblock',['calls_block',['../struct_t_a_b_l_e___g_r_a_p_h.html#ad99724809142c95d8a718639fbd9f051',1,'TABLE_GRAPH']]],
  ['calls_5fnb',['calls_nb',['../struct_f_u_n_c_t_i_o_n___d_e_t_a_i_l_s.html#aee42a6698bedc8b5876f7a08b9cf5363',1,'FUNCTION_DETAILS']]]
];
