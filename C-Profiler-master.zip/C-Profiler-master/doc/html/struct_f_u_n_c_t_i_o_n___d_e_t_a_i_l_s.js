var struct_f_u_n_c_t_i_o_n___d_e_t_a_i_l_s =
[
    [ "avg_time", "struct_f_u_n_c_t_i_o_n___d_e_t_a_i_l_s.html#a07a311ae30fa54f2799440fbfcf27358", null ],
    [ "calls_nb", "struct_f_u_n_c_t_i_o_n___d_e_t_a_i_l_s.html#aee42a6698bedc8b5876f7a08b9cf5363", null ],
    [ "fct", "struct_f_u_n_c_t_i_o_n___d_e_t_a_i_l_s.html#a2498e3312b0662da8a0399ffe6478ba2", null ],
    [ "runtime", "struct_f_u_n_c_t_i_o_n___d_e_t_a_i_l_s.html#a01143f6725f562bed4255476fa737925", null ]
];