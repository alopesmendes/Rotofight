var struct_t_a_b_l_e___g_r_a_p_h =
[
    [ "avg_block", "struct_t_a_b_l_e___g_r_a_p_h.html#a9bd66433ae403c710431a9f446985222", null ],
    [ "calls_block", "struct_t_a_b_l_e___g_r_a_p_h.html#ad99724809142c95d8a718639fbd9f051", null ],
    [ "is_sort_avg", "struct_t_a_b_l_e___g_r_a_p_h.html#aafd980d1238ae1b7381fdcb08f87e2ae", null ],
    [ "is_sort_calls", "struct_t_a_b_l_e___g_r_a_p_h.html#acba76a1a1d8dfb275c190fc1c3689405", null ],
    [ "is_sort_names", "struct_t_a_b_l_e___g_r_a_p_h.html#adf41696b38ba8576dfe77bd668b59544", null ],
    [ "is_sort_runtime", "struct_t_a_b_l_e___g_r_a_p_h.html#af9937dfbf0af46fac2dd5009a492b169", null ],
    [ "names_block", "struct_t_a_b_l_e___g_r_a_p_h.html#aec00d963ae6c37b27f0a6ac036860c32", null ],
    [ "runtime_block", "struct_t_a_b_l_e___g_r_a_p_h.html#aa73c6b0ddc77f32c05e9e4c04284aecc", null ],
    [ "table", "struct_t_a_b_l_e___g_r_a_p_h.html#a828eb93a270305cadb476eb617ae1c67", null ]
];