/**
 * \file Block.h
 * \brief Header of the module Block.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#ifndef __BLOCK__
#define __BLOCK__

#include <MLV/MLV_all.h>


/**
 * \struct BLOCK
 * \brief Block of a function.
 *
 * Contains the coordinates and the dimensions of a block of a function.
 * These coordinates and dimensions will be used to display the block.
 *
 */
typedef struct BLOCK {
	int x;		/*!< Coordinates x of the block. */
	int y;		/*!< Coordinates y of the block. */
	int w;		/*!< Width of the block. */
	int h;		/*!< Height of the block. */
} Block;


/**
 * \fn void init_block(Block *block, int x, int y, int w, int h)
 * \brief Initializes a block with the given coordinates.
 *
 * \param block Block of a function.
 * \param x Coordinates x of the block.
 * \param y Coordinates y of the block.
 * \param w Width of the block.
 * \param h Height x of the block.
 *
 */
void init_block(Block *block, int x, int y, int w, int h);


/**
 * \fn int point_intersect_block(const int x, const int y, const Block block)
 * \brief Checks if the coordinates x and y intersect with the block.
 *
 * \param x Coordinates x.
 * \param y Coordinates y.
 * \param block Block of a function.
 * \return An integer equals to 1 if `x` and `y` intersect with the block.
 * Otherwise returns 0.
 *
 */
int point_intersect_block(const int x, const int y, const Block block);


/**
 * \fn void draw_block(const Block block, MLV_Color color)
 * \brief Draws a block.
 *
 * \param block Block of a function.
 * \param color Color of the block.
 *
 */
void draw_block(const Block block, MLV_Color color);


/**
 * \fn void draw_filled_block(const Block block, MLV_Color color)
 * \brief Draws a filled block.
 *
 * \param block Block of a function.
 * \param color Color of the block.
 *
 */
void draw_filled_block(const Block block, MLV_Color color);


/**
 * \fn void draw_block_corners(const Block block, MLV_Color color)
 * \brief Draws a block with round corners.
 *
 * \param block Block of a function.
 * \param color Color of the block.
 *
 */
void draw_block_corners(const Block block, MLV_Color color);


/**
 * \fn void draw_filled_block_corners(const Block block, MLV_Color color)
 * \brief Draws a filled block with round corners.
 *
 * \param block Block of a function.
 * \param color Color of the block.
 *
 */
void draw_filled_block_corners(const Block block, MLV_Color color);

#endif