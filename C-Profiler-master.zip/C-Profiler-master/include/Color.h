/**
 * \file Color.h
 * \brief Header of the module Color.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#ifndef __Color__
#define __Color__

#include <MLV/MLV_all.h>

#define BACKGROUND_COLOR MLV_rgba(0, 26, 51, 255)
#define PARTIE_FOND MLV_rgba(100, 44, 32, 255)
#define BOX_COLOR MLV_rgba(102, 102, 153, 255)
#define INVISIBLE MLV_rgba(0, 0, 0, 0)

/**
 * \fn void tester_couleur(MLV_Color tab[], int taille)
 * \brief Displays defined colors.
 *
 * \param tab[] Array of colors.
 * \param taille Size of array.
 *
 */
void tester_couleur(MLV_Color tab[], int taille);

#endif