/**
 * \file Commands.h
 * \brief Header of the module Commands.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#ifndef __Commands__
#define __Commands__

#include "Tree_Block.h"
#include "Table_Graph.h"
#include <MLV/MLV_all.h>


/**
 * \fn int click_tree_block(Tree_Block_Array tree_blocks, int x, int y, int size)
 * \brief Finds which block was clicked on.
 *
 * \param tree_blocks Array of blocks.
 * \param x Coordinates x of the click.
 * \param y Coordinates y of the click.
 * \param size Number of drawn blocks.
 * \return An integer equals to -1 if no block was clicked on.
 * Otherwise returns the index of the block clicked.
 *
 */
int click_tree_block(Tree_Block_Array tree_blocks, int x, int y, int size);


/**
 * \fn MLV_Event action(Tree_Block_Array *tree_blocks, Table_Graph *table_graph, int size)
 * \brief Executes an action according to `MLV_EVENT`.
 *
 * \param tree_blocks Array of blocks.
 * \param table_graph Graphic table of functions.
 * \param size Number of drawn blocks.
 * \return The matched event.
 *
 */
MLV_Event action(Tree_Block_Array *tree_blocks, Table_Graph *table_graph, int size);

#endif