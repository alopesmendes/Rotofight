/**
 * \file Graph.h
 * \brief Header of the module Graph.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#ifndef __GRAPH__
#define __GRAPH__

#include <MLV/MLV_all.h>

/**
 * \fn void graph()
 * \brief Draws the graphic window.
 *
 */
void graph();

#endif