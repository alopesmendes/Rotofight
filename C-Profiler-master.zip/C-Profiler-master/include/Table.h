/**
 * \file Table.h
 * \brief Header of the module Table.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#ifndef __TABLE__
#define __TABLE__

#include "Tree.h"

/**
 * \def NB_FCT_MAX
 * \brief Maximum number of functions in a table.
 *
 */
#define NB_FCT_MAX 100


/**
 * \struct FUNCTION_DETAILS
 * \brief Function details.
 *
 * Contains all the details needed in a function : the function name,
 * the number of calls, the average time and the runtime.
 *
 */
typedef struct FUNCTION_DETAILS {
    char fct[SIZE_FCT_NAME];    /*!< String of the function name. */
    int calls_nb;               /*!< Number of calls. */
    double avg_time;            /*!< Average time. */
    double runtime;             /*!< Runtime. */
} Function_d;


/**
 * \struct TABLE
 * \brief Table of functions.
 *
 * Contains functions. Can be sorted by function name,
 * number of calls, average time and runtime.
 *
 */
typedef struct TABLE {
    Function_d fct_table[NB_FCT_MAX];   /*!< Array of the details of functions. */
    int nb_fct;                         /*!< Number of different functions in the array. */
} Table;


/**
 * \fn void create_table(Tree *tree, Table *t)
 * \brief Creates a table.
 *
 * Creates a `Table` using the function `create_table_aux`.
 * Insert all the details of every function in the array of `Table`.
 * Also counts the number of functions.
 *
 * \param tree Tree of functions.
 * \param t Table of functions.
 *
 */
void create_table(Tree *tree, Table *t);


/**
 * \fn void create_table_aux(Tree *tree, Table *t)
 * \brief Auxiliary function to create a table.
 *
 * Browses the tree node, checks if the function of the current node is already in the table.
 * Raises the number of calls and add the time of the function to the runtime.
 * Otherwise add the function to the table.
 *
 * \param tree Tree of functions.
 * \param t Table of functions.
 *
 */
void create_table_aux(Tree *tree, Table *t);


/**
 * \fn void decl_fct_in_table(Table *t, Tree *tree)
 * \brief Declares a function details in a table.
 *
 * The number of different functions in the table cannot exceed NB_FCT_MAX.
 *
 * \param t Table of functions.
 * \param tree Tree of functions.
 *
 */
void decl_fct_in_table(Table *t, Tree *tree);


/**
 * \fn void print_table(Table *t)
 * \brief Dislays a table in the terminal.
 *
 * \param t Table of functions.
 */
void print_table(Table *t);


/**
 * \fn int cmp_str_incr(const void *a, const void *b)
 * \brief Compares the arguments in ascending order of the function name.
 *
 * \param a First element to compare.
 * \param b Second element to compare.
 * \return An integer less than, equal to, or greater than zero
 * if *a is found, respectively, to be less than, to match, or be greater than *b.
 */
int cmp_str_incr(const void *a, const void *b);
/**
 * \fn int cmp_str_decr(const void *a, const void *b)
 * \brief Compares the arguments in descending order of the function name.
 *
 * \param a First element to compare.
 * \param b Second element to compare.
 * \return An integer less than, equal to, or greater than zero
 * if *b is found, respectively, to be less than, to match, or be greater than *a.
 */
int cmp_str_decr(const void *a, const void *b);


/**
 * \fn int cmp_calls_incr(const void *a, const void *b)
 * \brief Compares the arguments in ascending order of the number of calls.
 *
 * \param a First element to compare.
 * \param b Second element to compare.
 * \return An integer less than, equal to, or greater than zero
 * if *a is found, respectively, to be less than, to match, or be greater than *b.
 */
int cmp_calls_incr(const void *a, const void *b);
/**
 * \fn int cmp_calls_decr(const void *a, const void *b)
 * \brief Compares the arguments in descending order of the number of calls.
 *
 * \param a First element to compare.
 * \param b Second element to compare.
 * \return An integer less than, equal to, or greater than zero
 * if *b is found, respectively, to be less than, to match, or be greater than *a.
 */
int cmp_calls_decr(const void *a, const void *b);


/**
 * \fn int cmp_avg_incr(const void *a, const void *b)
 * \brief Compares the arguments in ascending order of the average time.
 *
 * \param a First element to compare.
 * \param b Second element to compare.
 * \return An integer less than, equal to, or greater than zero
 * if *a is found, respectively, to be less than, to match, or be greater than *b.
 */
int cmp_avg_incr(const void *a, const void *b);
/**
 * \fn int cmp_avg_decr(const void *a, const void *b)
 * \brief Compares the arguments in descending order of the average time.
 *
 * \param a First element to compare.
 * \param b Second element to compare.
 * \return An integer less than, equal to, or greater than zero
 * if *b is found, respectively, to be less than, to match, or be greater than *a.
 */
int cmp_avg_decr(const void *a, const void *b);


/**
 * \fn int cmp_runtime_incr(const void *a, const void *b)
 * \brief Compares the arguments in ascending order of the runtime.
 *
 * \param a First element to compare.
 * \param b Second element to compare.
 * \return An integer less than, equal to, or greater than zero
 * if *a is found, respectively, to be less than, to match, or be greater than *b.
 */
int cmp_runtime_incr(const void *a, const void *b);
/**
 * \fn int cmp_runtime_decr(const void *a, const void *b)
 * \brief Compares the arguments in descending order of the runtime.
 *
 * \param a First element to compare.
 * \param b Second element to compare.
 * \return An integer less than, equal to, or greater than zero
 * if *b is found, respectively, to be less than, to match, or be greater than *a.
 */
int cmp_runtime_decr(const void *a, const void *b);


/**
 * \fn void sort_table(Table *t, int (*sort_fct)(const void *, const void *))
 * \brief Sorts the table according to the comparison function.
 *
 * \param t Table of functions.
 * \param sort_fct Comparison function.
 *
 */
void sort_table(Table *t, int (*sort_fct)(const void *, const void *));


#endif