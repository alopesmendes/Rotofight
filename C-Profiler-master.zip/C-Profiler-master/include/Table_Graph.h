/**
 * \file Table_Graph.h
 * \brief Header of the module Table_Graph.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#ifndef __TABLE_GRAPH__
#define __TABLE_GRAPH__

#include <MLV/MLV_all.h>
#include "Table.h"
#include "Block.h"


/**
 * \def MLV_MAX_TEXT_SIZE
 * \brief Maximum length for a text.
 *
 */
#define MLV_MAX_TEXT_SIZE 15


/**
 * \struct TABLE_GRAPH
 * \brief Graphic table of functions.
 *
 */
typedef struct TABLE_GRAPH {
    Table table;			/*!< Table of functions. */
    Block names_block;		/*!< Coordinates for the block of functions name. */
    Block calls_block;		/*!< Coordinates for the block of calls number. */
    Block avg_block;		/*!< Coordinates for the block of average time. */
    Block runtime_block;	/*!< Coordinates for the block of runtime. */
    int is_sort_names;
    int is_sort_calls;
    int is_sort_avg;
    int is_sort_runtime;
} Table_Graph;


/**
 * \fn void init_table_graph(Table_Graph *table_graph, const Table table, int x, int y, int w, int h)
 * \brief Initializes the graphic for a table of functions.
 *
 * \param table_graph Graphic table of functions.
 * \param table Table of functions.
 * \param x Coordinates x of the graphic table.
 * \param y Coordinates y of the graphic table.
 * \param w Width of the graphic table.
 * \param h Height of the graphic table.
 *
 */
void init_table_graph(Table_Graph *table_graph, const Table table, int x, int y, int w, int h);


/**
 * \fn void draw_table_graph(Table_Graph *table_graph)
 * \brief Draws the graphic for a table of functions.
 *
 * \param table_graph Graphic table of functions.
 *
 */
void draw_table_graph(Table_Graph *table_graph);


/**
 * \fn void sort_table_graph(Table_Graph *table_graph, int sort_type)
 * \brief Sorts the graphic for a table of functions.
 *
 * \param table_graph Graphic table of functions.
 * \param sort_type Sort type.
 *
 */
void sort_table_graph(Table_Graph *table_graph, int sort_type);

#endif