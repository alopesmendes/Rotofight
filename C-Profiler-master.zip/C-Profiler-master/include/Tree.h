/**
 * \file Tree.h
 * \brief Header of the module Tree.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#ifndef __TREE__
#define __TREE__

/**
 * \def SIZE_FCT_NAME
 * \brief Maximum length of a function name.
 *
 */
#define SIZE_FCT_NAME 100


/**
 * \struct NODE
 * \brief Node of a tree.
 *
 * Contains the details of a node : the function name,
 * the execution time, the address of his son and his brother.
 *
 */
typedef struct NODE {
    char fct[SIZE_FCT_NAME];	/*!< String of a function name. */
    double tps;					/*!< Execution time. */
    struct NODE *son;			/*!< Address to a son. */
    struct NODE *brother;		/*!< Address to a brother. */
} Node, *Tree;


/**
 * \fn Node* load_node(char nom_fct[SIZE_FCT_NAME])
 * \brief Loads a node.
 *
 * \param nom_fct[SIZE_FCT_NAME] Function name.
 * \return A pointer to the allocated memory for the node.
 *
 */
Node* load_node(char nom_fct[SIZE_FCT_NAME]);


/**
 * \fn void parser(FILE *file, char str[SIZE_FCT_NAME], double *time)
 * \brief Parse a line in a file.
 *
 * The parsed line contains either the function name or `END`, with their time.
 * The function name or `END` is stored in the char array argument.
 * The time is stored in the argument of type double.
 *
 * \param file File with the functions.
 * \param str[SIZE_FCT_NAME] To store the function name or `END`.
 * \param time To store the time.
 *
 */
void parser(FILE *file, char str[SIZE_FCT_NAME], double *time);


/**
 * \fn void build_tree(Tree *t, FILE *file)
 * \brief Builds a tree of functions with a file.
 *
 * \param t Tree of functions.
 * \param file File with the functions.
 *
 */
void build_tree(Tree *t, FILE *file);


/**
 * \fn void build_tree_aux(Tree *t, FILE *file, char str[SIZE_FCT_NAME], double *time, Tree *father);
 * \brief Builds the tree.
 *
 * \param t Tree of functions.
 * \param file File with the functions.
 * \param str[SIZE_FCT_NAME] To store the function name or `END`.
 * \param time To store the time.
 * \param father Node of the father.
 *
 */
void build_tree_aux(Tree *t, FILE *file, char str[SIZE_FCT_NAME], double *time, Tree *father);


/**
 * \fn void free_tree(Tree *t)
 * \brief Free the tree.
 *
 * \param t Tree of functions.
 *
 */
void free_tree(Tree *t);


/**
 * \fn void print_prefixe(const Tree * const t)
 * \brief Displays the tree in a prefixe mode.
 *
 * \param t Tree of functions.
 *
 */
void print_prefixe(const Tree * const t);

#endif