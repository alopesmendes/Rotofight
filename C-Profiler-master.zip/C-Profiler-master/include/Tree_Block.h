/**
 * \file Tree_Block.h
 * \brief Header of the module Tree_Block.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#ifndef __TREE_BLOCK__
#define __TREE_BLOCK__


/**
 * \def MAX
 * \brief Default size for a `Tree_Block` array.
 *
 */
#define MAX 1000000

#include <MLV/MLV_all.h>
#include "Block.h"
#include "Tree.h"


/**
 * \struct TREE_BLOCK
 * \brief A block associated to its tree (node).
 *
 */
typedef struct TREE_BLOCK {
	Block block;	/*!< Associated block. */
	Tree tree;		/*!< Associated tree (node). */
} Tree_Block;


/**
 * \struct TREE_BLOCK_ARRAY
 * \brief An array of Tree_Block.
 *
 */
typedef struct TREE_BLOCK_ARRAY {
	Tree_Block* array;		/*!< Array of blocks. */
	int index;				/*!< Actual index of the array. */
	size_t size;			/*!< Size of the array. */
	size_t max;				/*!< Maximum size for realloc. */
} Tree_Block_Array;


/**
 * \fn void init_tree_block(Tree_Block *tree_block, const Tree tree, const Block block)
 * \brief Initializes a Tree_Block with a tree and a block.
 *
 * \param tree_block Tree_Block to create.
 * \param tree Associated tree.
 * \param block Associated block.
 *
 */
void init_tree_block(Tree_Block *tree_block, const Tree tree, const Block block);


/**
 * \fn void draw_tree_block(const Tree_Block tree_block, MLV_Color color)
 * \brief Draws a Tree_Block with a given color.
 *
 * \param tree_block Tree_Block to draw.
 * \param color Color of the tree_block.
 *
 */
void draw_tree_block(const Tree_Block tree_block, MLV_Color color);


/**
 * \fn void draw_tree_blocks(Tree_Block_Array t_blocks, const int w, const int h, int begin)
 * \brief Starts drawing all blocks of an Tree_Block array from a variable.
 *
 * \param t_blocks Array of Tree_Block.
 * \param x Coordinates x.
 * \param y Coordinates x.
 * \param w Width.
 * \param h Height.
 * \return The number of block which has been drawn.
 *
 */
int draw_tree_blocks(Tree_Block_Array t_blocks, const int x, const int y, const int w, const int h);


/**
 * \fn Tree_Block* init_tree_blocks()
 * \brief Loads an array of Tree_Block with default size MAX.
 *
 * \return A pointer to the allocated memory for the Tree_Block array.
 *
 */
Tree_Block* init_tree_blocks();


/**
 * \fn void init_tree_block_array(Tree_Block_Array* t_blocks)
 * \brief Initializes an array of Tree_Block with default values.
 *
 * \param t_blocks Array of Tree_Block.
 *
 */
void init_tree_block_array(Tree_Block_Array* t_blocks);


/**
 * \fn void init_t_blocks(const Tree * const tree, Tree_Block_Array* tree_blocks)
 * \brief Builds the tree of Tree_Block in the Tree_Block array.
 *
 * \param tree 
 * \param tree_blocks 
 *
 */
void init_t_blocks(const Tree * const tree, Tree_Block_Array* tree_blocks);


/**
 * \fn int resize_tree_block_array(Tree_Block **t_blocks, size_t size, size_t *max)
 * \brief Resizes the array of Tree_Block if `size` is more than `max`.
 *
 * \param t_blocks Array of Tree_Block.
 * \param size Size of the array.
 * \param max Maximum size for realloc.
 * \return An integer equals to 1 if the array of Tree_Block was resized.
 * Otherwise returns 0.
 *
 */
int resize_tree_block_array(Tree_Block **t_blocks, size_t size, size_t *max);


/**
 * \fn void free_tree_blocks(Tree_Block** array)
 * \brief Free the array of `Tree_Block`.
 *
 * \param array Array of Tree_Block.
 *
 */
void free_tree_blocks(Tree_Block** array);

#endif