/**
 * \file macro_profiler.h
 * \brief The profiling macro.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#ifndef __MACRO__PROFILAGE__
#define __MACRO__PROFILAGE__

/**
 * \def _POSIX_C_SOURCE
 * \brief Feature test macro for glibc.
 *
 */
#define _POSIX_C_SOURCE 199309L
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/**
 * \def PROFILE
 * \brief A define to capture and to write the time of a function into the opened file.
 *
 */
#define PROFILE struct timespec __time__; \
                FILE *__fichier_log__; \
                if ( strcmp(__FUNCTION__, "main") == 0 ) { \
                    __fichier_log__ = fopen("profile.log", "w+"); \
                } \
                else { \
                    if ( (__fichier_log__ = fopen("profile.log", "a")) == NULL ) { \
                        fprintf(stderr, "File could not be open\n"); \
                        exit(EXIT_FAILURE); \
                    } \
                } \
                clock_gettime(CLOCK_REALTIME, &__time__); \
                fprintf(__fichier_log__, "%s -- time : %ld.%lds\n", __FUNCTION__, __time__.tv_sec, __time__.tv_nsec); \
                fclose(__fichier_log__);

/**
 * \def return
 * \brief Redefine the return.
 *
 * The return is redefined to capture and to write the time of the end of a function.
 *
 */
#define return  if ( (__fichier_log__ = fopen("profile.log", "a")) == NULL ) { \
                    fprintf(stderr, "File could not be open\n"); \
                    exit(EXIT_FAILURE); \
                } \
                clock_gettime(CLOCK_REALTIME, &__time__); \
                fprintf(__fichier_log__, "END -- time : %ld.%lds\n", __time__.tv_sec, __time__.tv_nsec); \
                fclose(__fichier_log__); \
                return


#endif