/**
 * \file Block.c
 * \brief Contains the functions to draw a block.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <MLV/MLV_all.h>

#include "../include/Block.h"


static void draw_filled_round_corner(int x1, int x2, int y1, int y2, int r, MLV_Color color) {

    assert(r >= 0);
    MLV_draw_filled_ellipse(x1, y1, r / 2, r, color);
    MLV_draw_filled_ellipse(x2, y2, r, r / 2, color);

    return;
}

static void draw_round_corner(int x1, int x2, int y1, int y2, int r, MLV_Color color) {

    assert(r >= 0);
    MLV_draw_ellipse(x1, y1, r / 2, r, color);
    MLV_draw_ellipse(x2, y2, r, r / 2, color);

    return;
}

static void x_coordonates_corner(int tab_x[4], Block block, int r) {
    assert(r >= 0);
    tab_x[0] = block.x + r / 2;  
    tab_x[1] = block.x + (r + r / 5);
    tab_x[2] = (block.x + block.w) - r / 2; 
    tab_x[3] = (block.x + block.w) - (r + r / 5);
    
    return;
}

static void y_coordonates_corner(int tab_y[4], Block block, int r) {
    assert(r >= 0);
    tab_y[0] = block.y + r + r / 5;  
    tab_y[1] = block.y + r / 2;
    tab_y[2] = (block.y + block.h) - (r + r / 5); 
    tab_y[3] = (block.y + block.h) - (r / 2);

    return;
}

static void draw_corners(Block block, int r, MLV_Color color, void (*draw)(int, int, int, int, int, MLV_Color)) {
    int tab_x[4], tab_y[4];
    int i, j;
    assert(r >= 0);
    assert(NULL != draw);
    x_coordonates_corner(tab_x, block, r);
    y_coordonates_corner(tab_y, block, r);

    for (i = 0; i < 3; i += 2) {
        for (j = 0; j < 3; j += 2) {
            draw(
                tab_x[i], tab_x[i + 1],
                tab_y[j], tab_y[j + 1],
                r,
                color
            );
        }
    }

    return;
}


static void draw_outline(Block block, int diviseur) {
    int x1, x2, y1, y2;
    assert(diviseur > 0);

    x1 = block.x + block.w / diviseur;
    x2 = block.x + block.w - block.w / diviseur;
    y1 = block.y + block.h / diviseur;
    y2 = block.y + block.h - block.h / diviseur;

    MLV_draw_line(x1, block.y, x2, block.y, MLV_COLOR_BLACK);
    MLV_draw_line(x1, block.y + block.h, x2, block.y + block.h, MLV_COLOR_BLACK);
    MLV_draw_line(block.x, y1, block.x, y2, MLV_COLOR_BLACK);
    MLV_draw_line(block.x + block.w, y1, block.x + block.w, y2, MLV_COLOR_BLACK);

    return;
}


void init_block(Block *block, int x, int y, int w, int h) {
    assert(x >= 0);
    assert(y >= 0);
    assert(w >= 0);
    assert(h >= 0);
    assert(NULL != block);

    block->x = x;
    block->y = y;
    block->w = w;
    block->h = h;

    return;
}



int point_intersect_block(const int x, const int y, const Block block) {
    assert(x > 0);
    assert(y > 0);

    if  ((block.x <= x && x <= block.x + block.w) &&
        (block.y <= y && y <= block.y + block.h))
        return 1;

    return 0;
}   


void draw_block(const Block block, MLV_Color color) {
    MLV_draw_rectangle(
            block.x, block.y,
            block.w, block.h,
            color
        );

    return;
}

void draw_filled_block(const Block block, MLV_Color color) {
    MLV_draw_filled_rectangle(
            block.x, block.y,
            block.w, block.h,
            color
        );

    return;
}


void draw_block_corners(const Block block, MLV_Color color) {
    int diviseur, r, x, y;
    Block temp = {block.x - 1, block.y - 1, block.w + 2, block.h + 2};
    diviseur = 15;
    x = temp.x + temp.w / diviseur; 
    
    y = temp.y + temp.h / diviseur;
    
    r = (int)sqrt(pow(x - temp.x, 2) + (pow(y - temp.y, 2))) / 2;
    draw_outline(temp, diviseur);
    draw_corners(temp, r, color, &draw_round_corner);

    return;
}

void draw_filled_block_corners(const Block block, MLV_Color color) {
    int x[8], y[8];
    int diviseur, r;
    diviseur = 15;
    x[0] = x[5] = block.x + block.w / diviseur; y[2] = y[7] = block.y + block.h / diviseur;
    x[1] = x[4] = block.x + block.w - block.w / diviseur; y[3] = y[6] = block.y + block.h - block.h / diviseur;
    x[2] = x[3] = block.x + block.w; y[4] = y[5] = block.y + block.h;
    x[6] = x[7] = block.x; y[0] = y[1] = block.y;
    r = (int)sqrt(pow(x[0] - x[7], 2) + (pow(y[0] - y[7], 2))) / 2;
    draw_corners(block, r, color, &draw_filled_round_corner);

    MLV_draw_filled_polygon(x, y, 8, color);

    return;
}