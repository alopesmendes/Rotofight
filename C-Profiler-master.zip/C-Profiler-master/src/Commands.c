/**
 * \file Commands.c
 * \brief Contains the functions to control the program.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <MLV/MLV_all.h>

#include "../include/Tree_Block.h"
#include "../include/Table_Graph.h"
#include "../include/Commands.h"

int click_tree_block(Tree_Block_Array t_blocks, int x, int y, int size) {
	size_t i;
	int index = -1;
	int h = MLV_get_window_height(), w = MLV_get_window_width();
	assert(x >= 0);
	assert(y >= 0);
	for (i = t_blocks.index; i < t_blocks.size; ++i) { 
		if (point_intersect_block(x, y, t_blocks.array[i].block)) {
			if (t_blocks.array[i].block.w <= w && t_blocks.array[i].block.h <= h) {
				index = i;
				w = t_blocks.array[i].block.w; h = t_blocks.array[i].block.h;
			}
		}
	}
	return index;
}

MLV_Event action(Tree_Block_Array *t_blocks, Table_Graph *table_graph, int size) {
	MLV_Event event;
	MLV_Keyboard_button button;
	MLV_Button_state state;
	MLV_Mouse_button mouse;
	int x, y, index;

	event = MLV_get_event(
		&button,
		NULL, NULL,NULL, NULL,
		&x, &y,
		&mouse, 
		&state
	);

	switch(event) {
		case MLV_MOUSE_BUTTON : 
			if (state == MLV_PRESSED) {
				if ((mouse == MLV_BUTTON_LEFT) 
					&& (index = click_tree_block(*t_blocks, x, y, size)) != -1 ) {
					t_blocks->index = index;
				}
				else if (mouse == MLV_BUTTON_RIGHT) {
					t_blocks->index = t_blocks->index - 1 <= 0 ? 0 : t_blocks->index - 1; 
				}
				else if ( (mouse == MLV_BUTTON_LEFT)
					&& (point_intersect_block(x, y, table_graph->names_block)) ) {
					sort_table_graph(table_graph, 1);
				}
				else if ( (mouse == MLV_BUTTON_LEFT)
					&& (point_intersect_block(x, y, table_graph->calls_block)) ) {
					sort_table_graph(table_graph, 2);
				}
				else if ( (mouse == MLV_BUTTON_LEFT)
					&& (point_intersect_block(x, y, table_graph->avg_block)) ) {
					sort_table_graph(table_graph, 3);
				}
				else if ( (mouse == MLV_BUTTON_LEFT)
					&& (point_intersect_block(x, y, table_graph->runtime_block)) ) {
					sort_table_graph(table_graph, 4);
				}
				return MLV_MOUSE_BUTTON;
			}
			break;
		case MLV_KEY : 
			if (state == MLV_PRESSED)
				return MLV_KEY;
			break;
		default : 
			break;
	}

	return MLV_NONE;
}