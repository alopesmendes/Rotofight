/**
 * \file Graph.c
 * \brief Graphic window.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <MLV/MLV_all.h>

#include "../include/Tree.h"
#include "../include/Block.h"
#include "../include/Commands.h"
#include "../include/Color.h"
#include "../include/Tree_Block.h"
#include "../include/Table.h"
#include "../include/Table_Graph.h"
#include "../include/Graph.h"


static void log_input(char* dir, Tree *tree) {
	char log[100] = {'\0'};
	FILE *file = NULL;
	char* text;

	while (1) {
		MLV_wait_input_box(
			MLV_get_window_width() / 4, MLV_get_window_height() / 4,
		 	MLV_get_window_width() / 2, MLV_get_window_height() / 2,
		 	BOX_COLOR, MLV_COLOR_BLACK, BACKGROUND_COLOR, 
		 	"enter log %s", &text, dir
		);
		strcat(log, dir); strcat(log, text);
        free(text); text = NULL;
		if (NULL == (file = fopen(log, "r"))) {
            log[0] = '\0';
		}
		else {
			build_tree(tree, file);
			if (EOF == fclose(file)) {
				fprintf(stderr, "File corrupted could not be close\n");
			}
			return;
		}
	}
    return;
}

void graph() {
	MLV_Event event;
    int cpt;
    Tree tree = NULL;
    Table t;
    Table_Graph table_graph;
    Tree_Block_Array tree_blocks;
    MLV_create_window("ZiProfiler", "ZiProfiler", 
        1600, 800);
    init_tree_block_array(&tree_blocks);
    log_input("logs/", &tree);
    
    create_table(&tree, &t);
    sort_table(&t, &cmp_calls_incr);
    print_table(&t);

    init_t_blocks(&tree, &tree_blocks);
    init_table_graph(&table_graph, t, 1700/2, 25, 800/4, 750);

    cpt = draw_tree_blocks(tree_blocks, 30, 30, 800, 600);
    while ((event = action(&tree_blocks, &table_graph, cpt)) != MLV_KEY) {
        
        if (event == MLV_MOUSE_BUTTON) {
            MLV_clear_window(MLV_COLOR_BLACK);
            draw_table_graph(&table_graph);
            cpt = draw_tree_blocks(tree_blocks, 30, 30, 800, 600);
        }

        MLV_actualise_window();
    }

    MLV_wait_keyboard(NULL, NULL, NULL);
    MLV_free_window();
    free_tree_blocks(&(tree_blocks.array));

    free_tree(&tree);
}