/**
 * \file Table.c
 * \brief Contains the functions for the table.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 * Functions to create and to sort the table.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "../include/Tree.h"
#include "../include/Table.h"



void create_table(Tree *tree, Table *t) {
    int i, calls;
    double runtime;

    assert(NULL != tree);
    assert(NULL != t);

    t->nb_fct = 0;
    create_table_aux(tree, t);

    for (i = 0; i < t->nb_fct; ++i) {

        calls = t->fct_table[i].calls_nb;
        runtime = t->fct_table[i].runtime;
        t->fct_table[i].avg_time = runtime / calls;

    }

    return;
}


void create_table_aux(Tree *tree, Table *t) {
    int i, is_in_table = 0;

    assert(NULL != tree);
    assert(NULL != t);

    if (NULL == *tree) {
        return;
    }

    for (i = 0; i < t->nb_fct; ++i) {
        if ( strcmp( (*tree)->fct, t->fct_table[i].fct ) == 0 ) {
            t->fct_table[i].calls_nb += 1;
            t->fct_table[i].runtime += (*tree)->tps;
            is_in_table = 1;
            break;
        }
    }

    if (!is_in_table) {
        decl_fct_in_table(t, tree);
    }

    create_table_aux( &((*tree)->son), t );
    create_table_aux( &((*tree)->brother), t );

    return;
}


void decl_fct_in_table(Table *t, Tree *tree) {
    assert(NULL != tree);
    assert(NULL != t);

    t->nb_fct++;

    if ( t->nb_fct > NB_FCT_MAX ) {
        fprintf(stderr, "Table capacity overflow\n");
        exit(EXIT_FAILURE);
    }

    strcpy( t->fct_table[t->nb_fct - 1].fct, (*tree)->fct );
    t->fct_table[t->nb_fct - 1].calls_nb = 1;
    t->fct_table[t->nb_fct - 1].runtime = (*tree)->tps;
    t->fct_table[t->nb_fct - 1].avg_time = 0;

    return;
}


void print_table(Table *t) {
    int i;
    
    assert(NULL != t);

    printf("%-22s\tCALLS\tAVERAGE TIME\tRUNTIME\n\n", "FUNCTION");
    for (i = 0; i < t->nb_fct; ++i) {
        printf("%-22s\t%-6d\t%-12lf\t%-12lf\n",
            t->fct_table[i].fct, t->fct_table[i].calls_nb,
            t->fct_table[i].avg_time, t->fct_table[i].runtime
        );
    }
}



int cmp_str_incr(const void *a, const void *b) {
    Function_d *c_a = (Function_d *)a;
    Function_d *c_b = (Function_d *)b;
    return strcmp(c_a->fct, c_b->fct);
}

int cmp_str_decr(const void *a, const void *b) {
    Function_d *c_a = (Function_d *)a;
    Function_d *c_b = (Function_d *)b;
    return strcmp(c_b->fct, c_a->fct);
}

int cmp_calls_incr(const void *a, const void *b) {
    Function_d *c_a = (Function_d *)a;
    Function_d *c_b = (Function_d *)b;
    return c_a->calls_nb - c_b->calls_nb;
}

int cmp_calls_decr(const void *a, const void *b) {
    Function_d *c_a = (Function_d *)a;
    Function_d *c_b = (Function_d *)b;
    return c_b->calls_nb - c_a->calls_nb;
}

int cmp_avg_incr(const void *a, const void *b) {
    Function_d *c_a = (Function_d *)a;
    Function_d *c_b = (Function_d *)b;

    if (c_a->avg_time > c_b->avg_time) {
        return 1;
    }
    else if (c_a->avg_time < c_b->avg_time) {
        return -1;
    }
    else {
        return 0;
    }
}

int cmp_avg_decr(const void *a, const void *b) {
    Function_d *c_a = (Function_d *)a;
    Function_d *c_b = (Function_d *)b;

    if (c_b->avg_time > c_a->avg_time) {
        return 1;
    }
    else if (c_b->avg_time < c_a->avg_time) {
        return -1;
    }
    else {
        return 0;
    }
}

int cmp_runtime_incr(const void *a, const void *b) {
    Function_d *c_a = (Function_d *)a;
    Function_d *c_b = (Function_d *)b;

    if (c_a->runtime > c_b->runtime) {
        return 1;
    }
    else if (c_a->runtime < c_b->runtime) {
        return -1;
    }
    else {
        return 0;
    }
}

int cmp_runtime_decr(const void *a, const void *b) {
    Function_d *c_a = (Function_d *)a;
    Function_d *c_b = (Function_d *)b;

    if (c_b->runtime > c_a->runtime) {
        return 1;
    }
    else if (c_b->runtime < c_a->runtime) {
        return -1;
    }
    else {
        return 0;
    }
}

void sort_table(Table *t, int (*sort_fct)(const void *, const void *)) {    
    qsort( &(t->fct_table[0]), t->nb_fct, sizeof(Function_d), *sort_fct );
    return;
}