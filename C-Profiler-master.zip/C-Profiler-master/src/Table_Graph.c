/**
 * \file Table_Graph.c
 * \brief Contains the functions to display the table of functions.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <MLV/MLV_all.h>

#include "../include/Table_Graph.h"
#include "../include/Table.h"
#include "../include/Block.h"



void init_table_graph(Table_Graph *table_graph, const Table table, int x, int y, int w, int h) {
    assert(NULL != table_graph);

    table_graph->table = table;
    table_graph->is_sort_names = 0;
    table_graph->is_sort_calls = 0;
    table_graph->is_sort_avg = 0;
    table_graph->is_sort_runtime = 0;
    init_block( &(table_graph->names_block), x, y, w, h );
    init_block( &(table_graph->calls_block), x + w, y, w / 1.5, h );
    init_block( &(table_graph->avg_block), x + w + (w / 1.5), y, w, h );
    init_block( &(table_graph->runtime_block), x + (2 * w) + (w / 1.5), y, w, h );
}


static void draw_fct_names(Table_Graph *table_graph) {
    int i;
    int text_h, text_y = 50;

    assert(NULL != table_graph);

    MLV_draw_rectangle(
        table_graph->names_block.x, table_graph->names_block.y,
        table_graph->names_block.w, table_graph->names_block.h,
        MLV_COLOR_WHITE
    );

    MLV_draw_text(
        table_graph->names_block.x + 10,
        table_graph->names_block.y + 20,
        "FUNCTION NAME",
        MLV_COLOR_WHITE
    );

    for (i = 0; i < table_graph->table.nb_fct; ++i) {
        MLV_get_size_of_text(table_graph->table.fct_table[i].fct, NULL, &text_h);
        text_y += text_h;

        MLV_draw_text(
            table_graph->names_block.x + 10, text_y,
            table_graph->table.fct_table[i].fct,
            MLV_COLOR_WHITE
        );
    }
}

static void draw_fct_calls(Table_Graph *table_graph) {
    int i;
    int text_h, text_y = 50;
    char text_calls[MLV_MAX_TEXT_SIZE];

    assert(NULL != table_graph);

    MLV_draw_rectangle(
        table_graph->calls_block.x, table_graph->calls_block.y,
        table_graph->calls_block.w, table_graph->calls_block.h,
        MLV_COLOR_WHITE
    );

    MLV_draw_text(
        table_graph->calls_block.x + 10,
        table_graph->calls_block.y + 20,
        "CALLS NUMBER",
        MLV_COLOR_WHITE
    );

    for (i = 0; i < table_graph->table.nb_fct; ++i) {
        sprintf(text_calls, "%d", table_graph->table.fct_table[i].calls_nb);

        MLV_get_size_of_text(text_calls, NULL, &text_h);
        text_y += text_h;

        MLV_draw_text(
            table_graph->calls_block.x + 10, text_y,
            text_calls,
            MLV_COLOR_WHITE
        );
    }
}

static void draw_fct_avg(Table_Graph *table_graph) {
    int i;
    int text_h, text_y = 50;
    char text_calls[MLV_MAX_TEXT_SIZE];

    assert(NULL != table_graph);

    MLV_draw_rectangle(
        table_graph->avg_block.x, table_graph->avg_block.y,
        table_graph->avg_block.w, table_graph->avg_block.h,
        MLV_COLOR_WHITE
    );

    MLV_draw_text(
        table_graph->avg_block.x + 10,
        table_graph->avg_block.y + 20,
        "AVERAGE TIME",
        MLV_COLOR_WHITE
    );

    for (i = 0; i < table_graph->table.nb_fct; ++i) {
        sprintf(text_calls, "%lf", table_graph->table.fct_table[i].avg_time);

        MLV_get_size_of_text(text_calls, NULL, &text_h);
        text_y += text_h;

        MLV_draw_text(
            table_graph->avg_block.x + 10, text_y,
            text_calls,
            MLV_COLOR_WHITE
        );
    }
}

static void draw_fct_runtime(Table_Graph *table_graph) {
    int i;
    int text_h, text_y = 50;
    char text_calls[MLV_MAX_TEXT_SIZE];

    assert(NULL != table_graph);

    MLV_draw_rectangle(
        table_graph->runtime_block.x, table_graph->runtime_block.y,
        table_graph->runtime_block.w, table_graph->runtime_block.h,
        MLV_COLOR_WHITE
    );

    MLV_draw_text(
        table_graph->runtime_block.x + 10,
        table_graph->runtime_block.y + 20,
        "RUNTIME",
        MLV_COLOR_WHITE
    );

    for (i = 0; i < table_graph->table.nb_fct; ++i) {
        sprintf(text_calls, "%lf", table_graph->table.fct_table[i].runtime);

        MLV_get_size_of_text(text_calls, NULL, &text_h);
        text_y += text_h;

        MLV_draw_text(
            table_graph->runtime_block.x + 10, text_y,
            text_calls,
            MLV_COLOR_WHITE
        );
    }
}


void draw_table_graph(Table_Graph *table_graph) {
    assert(NULL != table_graph);

    draw_fct_names(table_graph);
    draw_fct_calls(table_graph);
    draw_fct_avg(table_graph);
    draw_fct_runtime(table_graph);
}


void sort_table_graph(Table_Graph *table_graph, int sort_type) {
    switch(sort_type) {
        case 1:
            table_graph->is_sort_names = (table_graph->is_sort_names == 1) ? 2 : 1;
            table_graph->is_sort_calls = table_graph->is_sort_avg = table_graph->is_sort_runtime = 0;
            break;

        case 2:
            table_graph->is_sort_calls = (table_graph->is_sort_calls == 1) ? 2 : 1;
            table_graph->is_sort_names = table_graph->is_sort_avg = table_graph->is_sort_runtime = 0;
            break;

        case 3:
            table_graph->is_sort_avg = (table_graph->is_sort_avg == 1) ? 2 : 1;
            table_graph->is_sort_calls = table_graph->is_sort_names = table_graph->is_sort_runtime = 0;
            break;

        case 4:
            table_graph->is_sort_runtime = (table_graph->is_sort_runtime == 1) ? 2 : 1;
            table_graph->is_sort_calls = table_graph->is_sort_names = table_graph->is_sort_avg = 0;
            break;

        default: break;
    }

    if (table_graph->is_sort_names > 0) {
        if (table_graph->is_sort_names == 1) {
            sort_table( &(table_graph->table), &cmp_str_incr );
        }
        else {
            sort_table( &(table_graph->table), &cmp_str_decr );
        }
    }

    else if (table_graph->is_sort_calls > 0) {
        if (table_graph->is_sort_calls == 1) {
            sort_table( &(table_graph->table), &cmp_calls_incr );
        }
        else {
            sort_table( &(table_graph->table), &cmp_calls_decr );
        }
    }

    else if (table_graph->is_sort_avg > 0) {
        if (table_graph->is_sort_avg == 1) {
            sort_table( &(table_graph->table), &cmp_avg_incr );
        }
        else {
            sort_table( &(table_graph->table), &cmp_avg_decr );
        }
    }

    else {
        if (table_graph->is_sort_runtime == 1) {
            sort_table( &(table_graph->table), &cmp_runtime_incr );
        }
        else {
            sort_table( &(table_graph->table), &cmp_runtime_decr );
        }
    }
}
