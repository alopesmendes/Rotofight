/**
 * \file Tree.c
 * \brief Contains the functions for the tree.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>

#include "../include/Tree.h"


Node* load_node(char nom_fct[SIZE_FCT_NAME]) {
    Node *adr = NULL;

    assert(NULL != nom_fct);

    if ( NULL == (adr = (Node *)malloc(sizeof(Node))) ) {
        exit(EXIT_FAILURE);
    }

    strcpy(adr->fct, nom_fct);
    adr->tps = 0;
    adr->son = NULL;
    adr->brother = NULL;

    return adr;
}


void parser(FILE *file, char str[SIZE_FCT_NAME], double *time) {
    char c;

    if (fscanf(file, "%s", str) != 1) {
        return;
    }
    fseek(file, 11, SEEK_CUR);
    if (fscanf(file, "%lf", time) != 1) {
        return;
    }

    do {
        c = fgetc(file);
    } while (c != EOF && c != '\n');

    return;
}


void build_tree(Tree *t, FILE *file) {
    char str[SIZE_FCT_NAME];
    double time;
    Tree father;

    build_tree_aux(t, file, str, &time, &father);

    return;
}

void build_tree_aux(Tree *t, FILE *file, char str[SIZE_FCT_NAME], double *time, Tree *father) {
    if (fgetc(file) == EOF) {
        return;
    }

    fseek(file, -1, SEEK_CUR);
    parser(file, str, time);

    if (strcmp(str, "END") != 0) {
        *t = load_node(str);
        (*t)->tps = *time;
    }

    else {
        (*father)->tps = *time - (*father)->tps;
        return;
    }

    build_tree_aux( &((*t)->son) , file, str, time, t);
    build_tree_aux( &((*t)->brother) , file, str, time, father);

    return;
}

void free_tree(Tree *t) {
    if (*t != NULL) {
        free_tree( &((*t)->son) );
        free_tree( &((*t)->brother) );

        free(*t);
        *t = NULL;
    }
}

void print_prefixe(const Tree * const t) {
    if ((*t) != NULL) {
        if ((*t)->son == NULL && (*t)->brother == NULL)
            printf("%s %lf end\n", (*t)->fct, (*t)->tps);
        else {
            printf("\t\t%s %lf - ", (*t)->fct, (*t)->tps);
            if ((*t)->son != NULL)
                printf(" son %s %lf", (*t)->son->fct, (*t)->tps);
            else if ((*t)->brother != NULL)
                printf(" brother %s %lf", (*t)->brother->fct, (*t)->tps);
            printf("\n");
        }

        print_prefixe( &((*t)->son) );
        print_prefixe( &((*t)->brother) );
    }
    
}