/**
 * \file Tree_Block.c
 * \brief Contains the functions to display the tree.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <MLV/MLV_all.h>

#include "../include/Block.h"
#include "../include/Tree.h"
#include "../include/Tree_Block.h"


static void draw_circle_to_continue(const Tree_Block t_block) {
	draw_tree_block(t_block, MLV_COLOR_GREEN);
	MLV_draw_filled_circle(
			t_block.block.x + t_block.block.w / 2 - t_block.block.w / 4, 
			t_block.block.y + t_block.block.h / 2,
			2,
			MLV_COLOR_BLACK);
		MLV_draw_filled_circle(
			t_block.block.x + t_block.block.w / 2 + t_block.block.w / 4,
			t_block.block.y + t_block.block.h / 2, 
			2, 
			MLV_COLOR_BLACK);
		MLV_draw_filled_circle(
			t_block.block.x + t_block.block.w / 2, 
			t_block.block.y + t_block.block.h / 2, 
			2, 
			MLV_COLOR_BLACK);
	return;
}

static void init_variables_draw(double *t, double *given_time, int *n_x, int *n_y, int *n_w, int *n_h, Tree_Block_Array *t_blocks, int i) {

	(*t) = t_blocks->array[i].tree->tps / (*given_time);
	(*t) = (*t) < 0.5 || (*t) > 1.0 ? 0.49 : (*t);
	*given_time = 1 - (*t);

	(*n_w) = (*n_w) < (*n_h) ? (*n_w) * (*t)  : ((*n_w) * (*t)) * (*t);
	(*n_h) = (*n_h) < (*n_w) ? (*n_h) * (*t)  : ((*n_h) * (*t)) * (*t);
	*n_x = t_blocks->array[i - 1].block.x + 5; 
	*n_y = t_blocks->array[i - 1].block.y + 30;

	if ((*n_w) >= (int)(t_blocks->array[i - 1].block.w * 0.9)  && (*n_h) >= (int)(t_blocks->array[i - 1].block.h * 0.9)) {
		*n_w = (*n_w) / 1.5;
		*n_h = (*n_h) / 1.5;
	}

}

static int draw_tree_blocks_ite(Tree_Block_Array *t_blocks, int x, int y, int w, int h) {
	Uint8 r, g, b, alpha;
	double t = 0, given_time = t_blocks->array[t_blocks->index].tree->tps;
	int n_w = w, n_h = h, n_x = x, n_y = y, i, j, cpt = 1;
	MLV_Color color = MLV_COLOR_RED;

	init_block(&(t_blocks->array[t_blocks->index].block), n_x, n_y, n_w, n_h);

	draw_tree_block(t_blocks->array[t_blocks->index], color);
	for (i = t_blocks->index + 1; i < t_blocks->size; ++i, ++cpt) {
		
		w = n_w; h = n_h;

		init_variables_draw(&t, &given_time, &n_x, &n_y, &n_w, &n_h, t_blocks, i);
		if (t_blocks->array[i - 1].tree->son != NULL)
			init_block(&(t_blocks->array[i].block), n_x, n_y, n_w, n_h);


		if (t_blocks->array[i - 1].tree->brother != NULL) {
			for (j = i - 1; j < t_blocks->size; ++j) {
				if (t_blocks->array[i - 1].tree->brother == t_blocks->array[j].tree) {
					n_x = n_w > n_h ? t_blocks->array[i].block.x + t_blocks->array[i].block.w + 5 : t_blocks->array[i].block.x + 5;
					n_y = n_h > n_w ? t_blocks->array[i].block.y + t_blocks->array[i].block.h + 30 : t_blocks->array[i].block.y;
					n_w = n_w > n_h ? n_w * given_time : n_w;
					n_w = n_h > n_w ? n_h * given_time : n_h;

					init_block(&(t_blocks->array[j].block), n_x, n_y, n_w, n_h);
					init_tree_block(&(t_blocks->array[j]), t_blocks->array[i - 1].tree->brother, t_blocks->array[j].block);
					MLV_convert_color_to_rgba(color, &r, &g, &b, &alpha);
					color = MLV_convert_rgba_to_color(r <= 0 ? 255 : r * t, 255 - r * t, b, alpha);
					draw_tree_block(t_blocks->array[j], color);

				}
					
			}
		}

		MLV_convert_color_to_rgba(color, &r, &g, &b, &alpha);
		color = MLV_convert_rgba_to_color(r <= 0 ? 255 : r * t, 255 - r * t, b, alpha);

		if (t < 0.5) {
			draw_circle_to_continue(t_blocks->array[i]);
			return cpt + 1;
		}
		else {
			if (t_blocks->array[i].block.x == 0 || t_blocks->array[i].block.y == 0
				|| t_blocks->array[i].block.w == 0 || t_blocks->array[i].block.h == 0)
				init_block(&(t_blocks->array[i].block), n_x, n_y, n_w, n_h);

			draw_tree_block(t_blocks->array[i], color);
		}
	}
	return cpt;
}


void init_tree_block(Tree_Block *tree_block, const Tree tree, const Block block) {
	assert(NULL != tree);
	tree_block->block = block;
	tree_block->tree = tree;
}

void init_t_blocks(const Tree * const tree, Tree_Block_Array* tree_blocks) {

    Block block;
    if ((*tree) != NULL) {

        init_block(&block, 0, 0, 0, 0);
        init_tree_block(&(tree_blocks->array[tree_blocks->size]), *tree, block);
        tree_blocks->size += 1;
        resize_tree_block_array(&(tree_blocks->array), tree_blocks->size, &tree_blocks->max);
        init_t_blocks( &((*tree)->son), tree_blocks);
        init_t_blocks( &((*tree)->brother), tree_blocks);

    }
    return;
}



void draw_tree_block(const Tree_Block tree_block, MLV_Color color) {
	int w, h, i = 0;
	char cpy[SIZE_FCT_NAME + SIZE_FCT_NAME], number[12];
	draw_block_corners(tree_block.block, MLV_COLOR_BLACK); draw_filled_block_corners(tree_block.block, color);
	

	strcpy(cpy, tree_block.tree->fct);
	sprintf(number, "%lf", tree_block.tree->tps);
	strcat(cpy, "[ "); strcat(cpy, number); strcat(cpy, " ]");
	strcat(cpy, " // son - "); strcat(cpy, tree_block.tree->son == NULL ? "None" : tree_block.tree->son->fct);
	strcat(cpy, " // brother - "); strcat(cpy, tree_block.tree->brother == NULL ? "None" : tree_block.tree->brother->fct);

	MLV_get_size_of_text(cpy, &w, &h);
	if (tree_block.block.w < w) {
		i = strlen(tree_block.tree->fct);
		MLV_get_size_of_text(cpy, &w, &h);
		while (tree_block.block.w < w) {
			i = i / 2;
			cpy[i] = '\0';
			MLV_get_size_of_text(cpy, &w, &h);
		}
	}
	MLV_draw_text(
		tree_block.block.x + tree_block.block.w / 30,
		tree_block.block.y,
		"%s", MLV_COLOR_WHITE, 
		cpy);

	return;
}

int draw_tree_blocks(Tree_Block_Array t_blocks, const int x, const int y, const int w, const int h) {
	return draw_tree_blocks_ite(&t_blocks, x, y, w, h);
}

Tree_Block* init_tree_blocks() {
	Tree_Block* array;

	if (NULL == (array = (Tree_Block*)malloc(MAX * sizeof(Tree_Block)))) {
		fprintf(stderr, "Allocation of Tree_Block array failed\n");
		exit(EXIT_FAILURE);
	}
	return array;
}

void init_tree_block_array(Tree_Block_Array *t_blocks) {
	assert(NULL != t_blocks);
	t_blocks->array = init_tree_blocks();
	t_blocks->size = 0;
	t_blocks->index = 0;
	t_blocks->max = MAX;
}

int resize_tree_block_array(Tree_Block **t_blocks, size_t size, size_t *max) {
	assert(NULL != t_blocks);
	Tree_Block* temp;
	if (size >= *max) {
		*max = (*max) * 2;
		if (NULL == (temp = (Tree_Block*)realloc(*t_blocks, sizeof(Tree_Block) * ((*max) * 2)))) {
			fprintf(stderr, "Realloc failed\n");
			return -1;
		}
		else {
			*t_blocks = temp;
			return 1;
		}
	}

	return 0;
}

void free_tree_blocks(Tree_Block** array) {
	assert(NULL != array);
	free(*array);
	*array = NULL;
}