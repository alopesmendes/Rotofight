/**
 * \file main.c
 * \brief Main program.
 * \author LOPES MENDES Ailton & LIN Gérald
 * \date December 2018 - January 2019
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <MLV/MLV_all.h>

#include "../include/Tree.h"
#include "../include/Block.h"
#include "../include/Commands.h"
#include "../include/Color.h"
#include "../include/Tree_Block.h"
#include "../include/Table.h"
#include "../include/Table_Graph.h"
#include "../include/Graph.h"


int main(int argc, char const *argv[]) {
    graph();

    return 0;
}